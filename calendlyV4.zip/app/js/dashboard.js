// Store the current active tab
let currentTab = 'dashboard';

// Function to load content from HTML files
async function loadContent(pageName) {
    try {
        // Map of special cases for file names
        const fileMap = {
            'test_api': 'test_api.html',
            'api_test': 'api_test.html',
            'very_simple_function': 'very_simple_function.html',
            'test': 'test.html',
            'settings': 'settings.html',
            'dashboard': 'dashboard.html'
        };

        const fileName = fileMap[pageName] || `${pageName}.html`;
        const response = await fetch(`../html/${fileName}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const content = await response.text();
        
        // Parse the content to get only the main content section
        const parser = new DOMParser();
        const doc = parser.parseFromString(content, 'text/html');
        
        // For API test pages, load the entire body content
        if (['test_api', 'api_test', 'very_simple_function'].includes(pageName)) {
            // Remove head content but keep scripts
            const scripts = Array.from(doc.head.getElementsByTagName('script'));
            const styles = Array.from(doc.head.getElementsByTagName('style'));
            
            // Clear existing scripts with same src
            scripts.forEach(script => {
                const existingScript = document.querySelector(`script[src="${script.src}"]`);
                if (existingScript) {
                    existingScript.remove();
                }
            });

            // Append scripts to document head
            scripts.forEach(script => {
                document.head.appendChild(script.cloneNode(true));
            });

            // Append styles to document head
            styles.forEach(style => {
                document.head.appendChild(style.cloneNode(true));
            });

            // Set the main content
            document.querySelector('main').innerHTML = doc.body.innerHTML;
        } else {
            // For regular pages, just get the main content
            const mainContent = doc.querySelector('main');
            if (mainContent) {
                document.querySelector('main').innerHTML = mainContent.innerHTML;
            } else {
                console.error('Main content section not found in the loaded HTML');
            }
        }

        // Update active tab styling
        updateActiveTab(pageName);
        
        // Update the browser history
        window.history.pushState({page: pageName}, '', `#${pageName}`);
        
        // Initialize Zoho SDK if loading API test pages
        if (['test_api', 'api_test', 'very_simple_function'].includes(pageName)) {
            if (typeof ZOHO !== 'undefined') {
                ZOHO.embeddedApp.init();
            }
        }
        
    } catch (error) {
        console.error('Error loading content:', error);
        document.querySelector('main').innerHTML = `
            <div class="p-8">
                <div class="bg-red-50 text-red-600 p-4 rounded-lg">
                    Error loading content: ${error.message}
                </div>
            </div>
        `;
    }
}

// Function to update active tab styling
function updateActiveTab(pageName) {
    // Remove active class from all tabs
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('text-primary', 'bg-primary-light');
        link.classList.add('text-gray-600', 'hover:bg-gray-50');
    });
    
    // Add active class to current tab
    const activeTab = document.querySelector(`[data-page="${pageName}"]`);
    if (activeTab) {
        activeTab.classList.remove('text-gray-600', 'hover:bg-gray-50');
        activeTab.classList.add('text-primary', 'bg-primary-light');
    }
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    // Add click event listeners to all navigation links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const pageName = link.getAttribute('data-page');
            if (pageName && pageName !== currentTab) {
                currentTab = pageName;
                loadContent(pageName);
            }
        });
    });

    // Handle browser back/forward buttons
    window.addEventListener('popstate', (event) => {
        if (event.state && event.state.page) {
            loadContent(event.state.page);
        }
    });

    // Load initial content based on hash or default to dashboard
    const initialPage = window.location.hash.slice(1) || 'dashboard';
    loadContent(initialPage);
});

// Export functions for potential use in other scripts
window.dashboardUtils = {
    loadContent,
    updateActiveTab
}; 